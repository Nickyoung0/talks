\echo Use "CREATE EXTENSION hello_pg" to load this file. \quit

CREATE FUNCTION hello_pg(text)
RETURNS text
AS 'MODULE_PATHNAME', 'hello_pg'
LANGUAGE C
IMMUTABLE STRICT PARALLEL SAFE;

COMMENT ON FUNCTION hello_pg(text)
IS 'Return Hello, <name>!; SQL NULL inputs return NULL without calling C';
