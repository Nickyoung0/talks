/* Minimal teaching extension. Source reference: master 23e7ca78a003. */
#include "postgres.h"

#include "fmgr.h"
#include "utils/builtins.h"

PG_MODULE_MAGIC;

PG_FUNCTION_INFO_V1(hello_pg);

Datum
hello_pg(PG_FUNCTION_ARGS)
{
	text	   *input = PG_GETARG_TEXT_PP(0);
	char	   *name = text_to_cstring(input);
	char	   *message = psprintf("Hello, %s!", name);
	text	   *result = cstring_to_text(message);

	pfree(name);
	pfree(message);
	PG_FREE_IF_COPY(input, 0);

	PG_RETURN_TEXT_P(result);
}
