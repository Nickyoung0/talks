CREATE SCHEMA hello_pg_test;
CREATE EXTENSION hello_pg WITH SCHEMA hello_pg_test;

DO $test$
BEGIN
    IF hello_pg_test.hello_pg('PostgreSQL') IS DISTINCT FROM 'Hello, PostgreSQL!' THEN
        RAISE EXCEPTION 'ASCII greeting failed';
    END IF;
    IF hello_pg_test.hello_pg('同学') IS DISTINCT FROM 'Hello, 同学!' THEN
        RAISE EXCEPTION 'UTF-8 greeting failed';
    END IF;
    IF hello_pg_test.hello_pg('') IS DISTINCT FROM 'Hello, !' THEN
        RAISE EXCEPTION 'Empty-string greeting failed';
    END IF;
    IF hello_pg_test.hello_pg(NULL::text) IS NOT NULL THEN
        RAISE EXCEPTION 'STRICT NULL behavior failed';
    END IF;
END
$test$;

CREATE TABLE hello_pg_test.inputs (name text);
INSERT INTO hello_pg_test.inputs VALUES (repeat('x', 100000));

DO $test$
BEGIN
    IF EXISTS (
        SELECT FROM hello_pg_test.inputs
        WHERE hello_pg_test.hello_pg(name)
              IS DISTINCT FROM ('Hello, ' || name || '!')
    ) THEN
        RAISE EXCEPTION 'Long stored text failed';
    END IF;
END
$test$;

DROP TABLE hello_pg_test.inputs;
DROP EXTENSION hello_pg;
DROP SCHEMA hello_pg_test;
